const mongoose = require("mongoose");

var ProcessSchema = new mongoose.Schema({
     
    Previous_employer: {
        type : String,
        
    },
    Designation: {
        type : String,
       
    },
    Experience: {
       type : String,
       
    },
    
} ,
     {
        toObject: {
          virtuals: true,
        },
        toJSON: {
          virtuals: true,
        },
});

mongoose.model("Process", ProcessSchema);